import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'usdToInr',
  standalone: true
})
export class UsdToInrPipe implements PipeTransform {
  transform(value: number): string {
    // Using a fixed conversion rate of 1 USD = 83 INR
    const inrValue = value * 83;
    return `₹${inrValue.toFixed(2)}`;
  }
}