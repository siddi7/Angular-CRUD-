import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { InputTextModule } from 'primeng/inputtext';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { InputNumberModule } from 'primeng/inputnumber';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { ProductService } from '../../services/product.service';
import { Product } from '../../models/product.model';

@Component({
  selector: 'app-product-form',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    InputTextModule,
    InputTextareaModule,
    InputNumberModule,
    ButtonModule,
    ToastModule
  ],
  providers: [MessageService],
  template: `
    <div class="container">
      <h1>{{isEditMode ? 'Edit' : 'Create'}} Product</h1>
      
      <form [formGroup]="productForm" (ngSubmit)="onSubmit()" class="flex flex-column gap-4">
        <div class="field">
          <label for="title">Product Name</label>
          <input 
            id="title" 
            type="text" 
            pInputText 
            formControlName="title" 
            class="w-full">
        </div>

        <div class="field">
          <label for="price">Price (USD)</label>
          <p-inputNumber 
            id="price" 
            formControlName="price"
            [minFractionDigits]="2"
            class="w-full">
          </p-inputNumber>
        </div>

        <div class="field">
          <label for="category">Category</label>
          <input 
            id="category" 
            type="text" 
            pInputText 
            formControlName="category"
            class="w-full">
        </div>

        <div class="field">
          <label for="description">Description</label>
          <textarea 
            id="description" 
            pInputTextarea 
            formControlName="description"
            [rows]="5" 
            class="w-full">
          </textarea>
        </div>

        <div class="field">
          <label for="stock">Stock</label>
          <p-inputNumber 
            id="stock" 
            formControlName="stock"
            [showButtons]="true"
            [min]="0"
            class="w-full">
          </p-inputNumber>
        </div>

        <div class="flex gap-2">
          <p-button 
            type="submit" 
            [label]="isEditMode ? 'Update' : 'Create'"
            [disabled]="productForm.invalid">
          </p-button>
          <p-button 
            type="button" 
            label="Cancel" 
            severity="secondary"
            routerLink="/products">
          </p-button>
        </div>
      </form>
    </div>
    <p-toast></p-toast>
  `
})
export class ProductFormComponent implements OnInit {
  productForm: FormGroup;
  isEditMode = false;
  productId?: number;

  constructor(
    private fb: FormBuilder,
    private productService: ProductService,
    private route: ActivatedRoute,
    private router: Router,
    private messageService: MessageService
  ) {
    this.productForm = this.fb.group({
      title: ['', Validators.required],
      price: [0, [Validators.required, Validators.min(0)]],
      category: ['', Validators.required],
      description: ['', Validators.required],
      stock: [0, [Validators.required, Validators.min(0)]]
    });
  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if (params['id']) {
        this.isEditMode = true;
        this.productId = params['id'];
        this.loadProduct(this.productId!);
      }
    });
  }

  loadProduct(id: number) {
    this.productService.getProduct(id).subscribe({
      next: (product) => {
        this.productForm.patchValue(product);
      },
      error: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to load product'
        });
      }
    });
  }

  onSubmit() {
    if (this.productForm.valid) {
      const product: Product = this.productForm.value;
      
      const request = this.isEditMode
        ? this.productService.updateProduct(this.productId!, product)
        : this.productService.createProduct(product);

      request.subscribe({
        next: () => {
          this.messageService.add({
            severity: 'success',
            summary: 'Success',
            detail: `Product ${this.isEditMode ? 'updated' : 'created'} successfully`
          });
          this.router.navigate(['/products']);
        },
        error: () => {
          this.messageService.add({
            severity: 'error',
            summary: 'Error',
            detail: `Failed to ${this.isEditMode ? 'update' : 'create'} product`
          });
        }
      });
    }
  }
}