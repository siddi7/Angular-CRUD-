import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { ProductService } from '../../services/product.service';
import { Product } from '../../models/product.model';
import { UsdToInrPipe } from '../../pipes/usd-to-inr.pipe';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    TableModule,
    ButtonModule,
    ToastModule,
    UsdToInrPipe
  ],
  providers: [MessageService],
  template: `
    <div class="container">
      <div class="flex justify-content-between align-items-center mb-4">
        <h1>Products</h1>
        <p-button 
          label="Add Product" 
          icon="pi pi-plus" 
          [routerLink]="['/product/new']">
        </p-button>
      </div>

      <p-table 
        [value]="products" 
        [paginator]="true" 
        [rows]="10"
        [responsive]="true"
        styleClass="p-datatable-gridlines">
        <ng-template pTemplate="header">
          <tr>
            <th>Name</th>
            <th>Price</th>
            <th>Category</th>
            <th>Description</th>
            <th>Stock</th>
            <th>Actions</th>
          </tr>
        </ng-template>
        <ng-template pTemplate="body" let-product>
          <tr>
            <td>{{product.title}}</td>
            <td>{{product.price | usdToInr}}</td>
            <td>{{product.category}}</td>
            <td>{{product.description}}</td>
            <td>{{product.stock}}</td>
            <td>
              <div class="flex gap-2">
                <p-button 
                  icon="pi pi-pencil" 
                  severity="warning"
                  [routerLink]="['/product']"
                  [queryParams]="{id: product.id}">
                </p-button>
                <p-button 
                  icon="pi pi-eye" 
                  severity="info"
                  [routerLink]="['/product/view', product.id]">
                </p-button>
              </div>
            </td>
          </tr>
        </ng-template>
      </p-table>
    </div>
    <p-toast></p-toast>
  `
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];

  constructor(
    private productService: ProductService,
    private messageService: MessageService
  ) {}

  ngOnInit() {
    this.loadProducts();
  }

  loadProducts() {
    this.productService.getProducts().subscribe({
      next: (response) => {
        this.products = response.products;
      },
      error: () => {
        this.messageService.add({
          severity: 'error',
          summary: 'Error',
          detail: 'Failed to load products'
        });
      }
    });
  }
}